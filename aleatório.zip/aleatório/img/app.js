const imgs = [{
    img: "./img/foto1.png"
},{
    img:"./img/foto2.png"
},{
    img:"./img/foto3.png"
},{
    img:"./img/foto4.png"
},{
    img:"./img/foto5.png"
},{
    img:"./img/foto6.png"
}]

const imgs = document.querySelector('.imgs')

window.addEventListener('DOMContentLoaded', function(){
    menuImg(imgs)
})

function menuImg(itens){
      let displayMenu = menuItems.map(function(item){
        return `<div class="imgs">
            <img src=${item.img} width="60px" height="60px">
          </div>`
          
          
      })
    displayMenu = displayMenu.join("")
    
    box.innerHTML = displayMenu
}

    